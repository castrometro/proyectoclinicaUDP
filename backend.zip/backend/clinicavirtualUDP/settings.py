import pymysql
pymysql.install_as_MySQLdb()

from pathlib import Path
from datetime import timedelta
import os

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# Quick-start development settings - unsuitable for production
SECRET_KEY = "django-insecure-3#4t(+#rft2x_=k#@!vnof3gk73(_+*fab%-i5l9wpy3q53hn7"
DEBUG = True
ALLOWED_HOSTS = ['fichaclinica.udp.cl', 'www.fichaclinica.udp.cl']

# Application definition
INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    'rest_framework',
    'api',
    'corsheaders',
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
    'corsheaders.middleware.CorsMiddleware',
]

ROOT_URLCONF = "clinicavirtualUDP.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "clinicavirtualUDP.wsgi.application"

# Database
DATABASES = {
    # "default": {
    #     "ENGINE": "django.db.backends.postgresql",
    #     "NAME": "clinicaUDP",
    #     "USER": "postgres",
    #     "PASSWORD": "HgE#3q!ZsNb*Tmu",
    #     "HOST": "44.220.155.104",
    #     "PORT": "5432",
    # },
    # "default": {
    #     "ENGINE": "django.db.backends.mysql",
    #     "HOST": "labcal-certificacion.c6vjk11gxhuf.us-east-1.rds.amazonaws.com",
    #     "USER": "root",
    #    "PASSWORD": "20419-0Dav",
    #     "NAME": "pablo_db",
    #     "PORT": 3306,
    # }
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'fichaclinicaudp_db',
        'USER': 'fichaclinicaudp_admin_back',
        'PASSWORD': 'administrador2025UDP_',
        'HOST': 'localhost',  
        'PORT': '3306',
    }
    
}

# Password validation
AUTH_PASSWORD_VALIDATORS = [
    {
        "NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.CommonPasswordValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.NumericPasswordValidator",
    },
]

# Internationalization
LANGUAGE_CODE = "en-us"
TIME_ZONE = "UTC"
USE_I18N = True
USE_TZ = True

# Static files (CSS, JavaScript, Images)
STATIC_URL = '/static/'  # Ruta para servir archivos estáticos
STATIC_ROOT = '/home/fichaclinicaudp/backend/static/'  # Carpeta en el servidor donde se recopilan los archivos estáticos


# Default primary key field type
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

CORS_ALLOW_ALL_ORIGINS = True

REST_FRAMEWORK = {
    'DEFAULT_AUTHENTICATION_CLASSES': (
        'rest_framework_simplejwt.authentication.JWTAuthentication',
    ),
}

SIMPLE_JWT = {
    'ACCESS_TOKEN_LIFETIME': timedelta(minutes=60),
    'REFRESH_TOKEN_LIFETIME': timedelta(days=1),
    'ROTATE_REFRESH_TOKENS': True,
    'BLACKLIST_AFTER_ROTATION': True,
    'AUTH_HEADER_TYPES': ('Bearer',),
}
